package project1.ver07;

public interface SubMenuItem {
int commonAdd = 1,  SchoolAdd = 2, CompanyAdd = 3;
}