package project1.ver07;

public interface MenuItem {
	int Input = 1, Search = 2, Delete = 3, AllShow = 4, Exit = 5;
}
