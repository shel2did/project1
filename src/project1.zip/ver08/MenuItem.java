package project1.ver08;

public interface MenuItem {
	int Input = 1, Search = 2, Delete = 3, 
			AllShow = 4, AutoSave = 5, Exit = 6,
			Game = 7;
}
