package project1.ver06;

public interface SubMenuItem {
int commonAdd = 1,  SchoolAdd = 2, CompanyAdd = 3;
}