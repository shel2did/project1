package project1.ver05;

public interface SubMenuItem {
int commonAdd = 1,  SchoolAdd = 2, CompanyAdd = 3;
}