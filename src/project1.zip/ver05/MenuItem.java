package project1.ver05;

public interface MenuItem {
	int Input = 1, Search = 2, Delete = 3, AllShow = 4, Exit = 5;
}
