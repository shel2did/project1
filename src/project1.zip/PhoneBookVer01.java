package project1;

import project1.ver01.PhoneInfo;

public class PhoneBookVer01 {
	public static void main(String[] args) {
			PhoneInfo test1 = new PhoneInfo("뀨", "010-1111-1111", "95.02.15");
			PhoneInfo test2 = new PhoneInfo("테스트", "010-0000-0000");
	}
}